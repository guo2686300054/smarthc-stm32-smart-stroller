#include "sys.h"
#include "delay.h"
#include "step.h"
//IN4: PB6  d
//IN3: PB5  c
//IN2: PB4  b
//IN1: PB3   a
//�������
u8 phasecw[8] ={0x08,0x0c,0x04,0x06,0x02,0x03,0x01,0x09};// ��ʱ��100000001100000001000000011000000010000000110000000100001001
u8 phaseccw[8]={0x09,0x01,0x03,0x02,0x06,0x04,0x0c,0x08};// ˳ʱ��100100000001000000110000001000000110000001000000110000001000


//���ų�ʼ��
void Step_Motor_GPIO_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);//��AFIOʱ��

    GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);   //Full SWJ Disabled (JTAG-DP + SW-DP)  
   // �ı�ָ���ܽŵ�ӳ�� GPIO_Remap_SWJ_Disable SWJ ��ȫ���ã�JTAG-DP+SW-DP��

    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable , ENABLE); //JTAG-DP Disabled and SW-DP Enabled
   // �ı�ָ���ܽŵ�ӳ�� GPIO_Remap_SWJ_JTAGDisable ��JTAG-DP ���� + SW-DP ʹ��

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
    GPIO_Init(GPIOB,&GPIO_InitStructure);   
}
//����ӳ��
void SetMotor(char InputData)
{
    if(InputData&0x01)
    {
        GPIO_SetBits(GPIOB,GPIO_Pin_4);
    }
    else
    {
        GPIO_ResetBits(GPIOB,GPIO_Pin_4);
    }
    if(InputData&0x02)
    {
        GPIO_SetBits(GPIOB,GPIO_Pin_5);
    }
    else
    {
        GPIO_ResetBits(GPIOB,GPIO_Pin_5);

    }
    if(InputData&0x04)
    {
        GPIO_SetBits(GPIOB,GPIO_Pin_6);
    }
    else
    {
        GPIO_ResetBits(GPIOB,GPIO_Pin_6);
    }
    if(InputData&0x08)
    {
        GPIO_SetBits(GPIOB,GPIO_Pin_7);
    }
    else
    {
        GPIO_ResetBits(GPIOB,GPIO_Pin_7);
    }
}
//�����5.625 360/5.625=64 ���ٱ�1/64 
//��64*64������תһȦ
//nȦ�� 
//position ����
void motorNcircle(int n,bool position)
{
    int i,j,k=0;
    for(j=0;j<n;j++)
    {
        //for(i=0;i<64*8;i++)
        for(i=0;i<8;i++)
        {
            for(k=0;k<8;k++)
            {
                if(1 == position)
                {
                    SetMotor(phasecw[k]);
                }
                else if(0 == position)
                {
                    SetMotor(phaseccw[k]);
                }
                DelayMs(2);
            }
        }
    }
}
