#ifndef __STEP_H
#define __STEP_H
#include "stdio.h"	
#include "sys.h" 
typedef enum {FALSE =0,TRUE =1} bool;

void Step_Motor_GPIO_Init(void);
void SetMotor(char InputData);
void motorNcircle(int n,bool position);

#endif

