#include "MOTOR.h"
#include "delay.h"
#include "led.h"   

unsigned char Time=3;

void MOTOR_GPIO_Init(void)
{
	  GPIO_InitTypeDef  GPIO_InitStructure;
	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PB�˿�ʱ��
	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_4| GPIO_Pin_3 | GPIO_Pin_2;				 // �˿�����
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		      //��������
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	  GPIO_Init(GPIOA, &GPIO_InitStructure);	
}

//˳ʱ��ת��
void MotorCW(void)
{
    unsigned short i;
    for(i=0; i<100; i++)
    {
        Coil_A1;
        DelayMs(3);
        Coil_B1;
        DelayMs(3);
        Coil_C1;
        DelayMs(3);
        Coil_D1;
        DelayMs(3);
    }
		Coil_OFF;
			RELAY = 1;//��������ģʽָʾ��
		  
}
//��ʱ��ת��
void MotorCCW(void)
{
    unsigned short i;
    for(i=0; i<100; i++)
    {
        Coil_D1;
    DelayMs(3);
        Coil_C1;
    DelayMs(3);
        Coil_B1;
    DelayMs(3);
        Coil_A1;
    DelayMs(3);
    }
		Coil_OFF;
			RELAY = 0;//�����ر�ģʽָʾ��
}

void MotorStop(void)
{
		Coil_OFF;
}



