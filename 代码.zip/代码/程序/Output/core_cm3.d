..\..\output\core_cm3.o: ..\..\Libraries\CMSIS\core_cm3.c
..\..\output\core_cm3.o: D:\c51prt\Mdk\ARM\ARMCC\Bin\..\include\stdint.h
