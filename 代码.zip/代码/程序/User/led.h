#ifndef __LED_H
#define __LED_H	 
#include "sys.h"

#define 	KEY1 PBin(12)
#define 	KEY2 PBin(13)
#define 	KEY3 PBin(14)
#define 	RTHW PAin(11)
#define BJ_LED PBout(11)
#define BGD PBout(9)  
#define YL PBout(15)  

#define 	BEEP PBout(6)
#define 	RELAY PAout(15)
#define 	RELAY1 PAout(12)
void BEEP_ENABLE(void);   //BEEP��
void BEEP_DISENABLE(void); //BEEP��
void RELAY_Init(void);
void RELAY1_Init(void);
void KEY_IO_Init(void);
void LED_Init(void);//��ʼ�� 	
void BEEP_GPIO_Config(void);
#endif


