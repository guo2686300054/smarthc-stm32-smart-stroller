#include "stm32f10x.h"
#include "OLED_I2C.h"
#include "led.h"
#include "delay.h"
#include "usart1.h"
#include "timer.h"
#include "key.h"
#include "adc.h"
#include "dht11.h"
#include "stdio.h"
#include "string.h"
#include "MOTOR.h"
#include "esp8266.h"
uint8_t mode ;
uint8_t mode1 ;
uint8_t mode2 ;
uint8_t mode3;
unsigned char baojing2[50];//�¶ȴ洢�ռ�
unsigned char baojing1[16];//ʪ�ȴ洢�ռ�
unsigned char wendu[16];//ʪ�ȱ����ռ�
unsigned char shidu[16];//�¶ȱ����ռ�
bool usart_send_flag=0;
u8 Temperature,HUM; 
unsigned int PPM_MAX=70;
u16 Temperature_MAX = 40;
unsigned char setn = 0;
unsigned int PPM;
unsigned int PPM1=20;
unsigned int PPM2=30;
void KeyScan(void)
{
	      char i,k=19;
	       if(KEY1==0)
		       {
				      DelayMs(20);
			        if(KEY1==0)
				      {
					     	while(KEY1==0);//�ȴ������ɿ�
					       OLED_CLS();//����
					       setn++;
					       if(setn > 2)//��ת����ʼ������
					       {
							      setn = 0;
						  	   for(i=k-18;i<k-13;i++)
	                 {
	                 	OLED_ShowCN(16+(i-1)*16,0,i);
	                 }
	                 for(i=k-10;i<k-8;i++)
	                 {
	                 	OLED_ShowCN((i-9)*16,3,i);
	                  }
	                 for(i=k-4;i<k-2;i++)
	                  {  
		                OLED_ShowCN((i-15)*16,6,i);
	                   }
									sprintf(baojing1,": %d ",PPM_MAX);
	                OLED_ShowStr(80,6,baojing1,2); 
	                sprintf(baojing2,": %d ",Temperature_MAX);
	                OLED_ShowStr(35,6,baojing2,2); 
					  }
					if(setn == 1)//��������Ũ�ȱ���ֵ
					{
             	for(i=k-18;i<k-13;i++)
	            {
		            OLED_ShowCN(16+(i-1)*16,0,i);
	              }		
	           for(i=k-10;i<k-8;i++)
	          {
		          OLED_ShowCN((i-9)*16,3,i);
           	}
	         for(i=k-4;i<k-2;i++)
	            {  
	            	OLED_ShowCN((i-15)*16,6,i);
	}
							sprintf(baojing2,": %d ",Temperature_MAX);
		          OLED_ShowStr(35,6,baojing2,2); 
						
						  
					}
					if(setn == 2)//������������ֵ
					{
			for(i=k-18;i<k-13;i++)
	 {
		 OLED_ShowCN(16+(i-1)*16,0,i);
	  }		
	for(i=k-10;i<k-8;i++)
	{
		OLED_ShowCN((i-9)*16,3,i);
	}
	for(i=k-4;i<k-2;i++)
	{  
		OLED_ShowCN((i-15)*16,6,i);
	}
							sprintf(baojing1,": %d ",PPM_MAX);
		          OLED_ShowStr(80,6,baojing1,2); 
					}
				}
		}
		if(KEY2==0)
		{
				DelayMs(20);
			  if(KEY2==0)
				{
						while(KEY2==0);
					  if(setn == 1)
					{
							if(Temperature_MAX < 100)Temperature_MAX++;
						  sprintf(baojing2,": %d ",Temperature_MAX);
		          OLED_ShowStr(30,6,baojing2,2); 
					}
					if(setn == 2)
					{
						  if(PPM_MAX < 100)PPM_MAX++;
						  sprintf(baojing1,": %d ",PPM_MAX);
		          OLED_ShowStr(80,6,baojing1,2);   
					}
					  
				}
		}
		if(KEY3==0)
		{
				DelayMs(20);
			  if(KEY3==0)
				{
						while(KEY3==0);
					if(setn == 1)
					{
							if(Temperature_MAX > 0)Temperature_MAX--;
						  sprintf(baojing2,": %d ",Temperature_MAX);
		          OLED_ShowStr(30,6,baojing2,2); 
						  
					}
					if(setn == 2)
					{
						  if(PPM_MAX > 0)PPM_MAX--;
						  sprintf(baojing1,": %d ",PPM_MAX);
		          OLED_ShowStr(80,6,baojing1,2);   
					} 
				}
		}
}
int main(void)//������
{
	u16 timeCount1=300;
	u16 timeCount2=1; 
	u16 test_adc,count=0;
	u8 send_flag = 0;
	char i,k=19;
	KEY_IO_Init();
	DelayInit();
	I2C_Configuration(); //IIC��ʼ��
	OLED_Init(); //OLED��ʼ��
	DelayMs(200);
  OLED_CLS();//����
  DHT11_Init();//��ʪ�ȴ�������ʼ��
	Adc_Init();
	LED_Init();
	RELAY1_Init();
  ESP8266_Init();
	MOTOR_GPIO_Init();   // �����ʼ��
	BEEP_GPIO_Config();
	for(i=k-18;i<k-12;i++)
	{
		OLED_ShowCN(16+(i-1)*16,0,i);
	}
	for(i=k-10;i<k-8;i++)
	{
		OLED_ShowCN((i-9)*16,3,i);
	}
	for(i=k-4;i<k-2;i++)
	{  
		OLED_ShowCN((i-15)*16,6,i);
	}
	BEEP_GPIO_Config(); //��������ʼ��
	sprintf(baojing1,": %d ",PPM_MAX);
	OLED_ShowStr(80,6,baojing1,2); 
	sprintf(baojing2,": %d ",Temperature_MAX);
	OLED_ShowStr(35,6,baojing2,2); 
		YL = 1;
	
	while(1)
	{
		    KeyScan();
		    test_adc = Get_Adc_Average(ADC_Channel_9,20);//��ȡͨ��9��20��ADƽ��ֵ
				PPM = test_adc*99/4096;//ת����0-99�ٷֱ�
				PPM = PPM >= 99? 99: PPM;//���ȡ�ٷ�֮
       timeCount2 ++;
			 if(timeCount2 >= 3)
			 {
					timeCount2 = 0;
				  usart_send_flag = 1;
			 }
		      DHT11_Read_Data(&Temperature,&HUM);
			    sprintf(wendu,": %dC ",Temperature);
		      OLED_ShowStr(30,3,wendu,2);
			    sprintf(shidu,":%drh ",HUM);
		      OLED_ShowStr(78,3,shidu,2);
			 
			
		if(RTHW ==1 ||HUM>PPM_MAX)
					{
						
						BJ_LED = 1;
						
					}
				else
				{
					
				    BJ_LED = 0;
				}
				if(RTHW ==1 )
					{
						PPM2 = 50;
						
						
					}
				else
				{
					PPM2 = 30;
				    
				}
				
				if(mode ==1&&mode1 ==1)
				{
					RELAY1 = 1;
				   if(send_flag == 0)
							    {
									    send_flag = 1;
						          RELAY1 = 0;//�̵�������
										 DelayMs(2000);
										 RELAY1 = 1;//�̵�������
										 
									}
				 
				
				}
				else
				{
					     RELAY1 = 1;
				       RELAY1 = 0;//�̵�������
					
					    send_flag = 0;
				    	
				} 
				if(mode ==1&&mode2 ==1)
				{
				
					 BGD = 1;//�̵�������
								
				
				}
				else
				{
				     BGD = 0;//�̵�������

				} 
				if(mode ==1&&mode3 ==1)
				{
				
						 if(RELAY==1)//��������ǹرյ�
					           {
			                  MotorCCW();//���Ƶ������������
						
					            } 
					           if(RELAY==0) //��������Ǵ򿪵�
					          {
			                 MotorCW();//���Ƶ����ת�رմ���
						
					           }       

				}
				else
				{
				   
              MotorStop();
				} 
		if(mode ==0)
		{
			YL = 1;
			 if(Temperature>Temperature_MAX)
					{
						
						BGD = 1;

					}
				else
				{
				    BGD = 0;
				}
				
		   if(PPM > 10)
					{
						 PPM1 = 30;
						 if(send_flag == 0)
							    {
									    send_flag = 1;
						          RELAY1 = 0;//�̵�������
										  if(RELAY==1)//��������ǹرյ�
					           {
			                  MotorCCW();//���Ƶ������������
						
					            } 
					           if(RELAY==0) //��������Ǵ򿪵�
					          {
			                 MotorCW();//���Ƶ����ת�رմ���
						
					           } 
						     	}
						
					}
				else
				{
				     RELAY1 = 1;//�̵�������
					    send_flag = 0;
				    	MotorStop();
					PPM1 = 20;
				} 
				
		   
	}
	else
				{
				     YL = 0;//�̵�������
					  
				}  	
}
}

